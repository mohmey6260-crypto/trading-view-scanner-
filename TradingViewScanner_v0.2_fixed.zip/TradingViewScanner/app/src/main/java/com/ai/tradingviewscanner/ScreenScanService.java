package com.ai.tradingviewscanner;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.util.DisplayMetrics;

public class ScreenScanService extends Service {
    public static final String EXTRA_RESULT_CODE = "result_code";
    public static final String EXTRA_RESULT_DATA = "result_data";

    private MediaProjection projection;
    private ImageReader reader;
    private VirtualDisplay virtualDisplay;
    private HandlerThread thread;
    private Handler handler;

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        createNotificationChannel();
        Notification n = new Notification.Builder(this, "scan")
                .setContentTitle("TV Signal Scanner")
                .setContentText("در حال اسکن صفحه")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(7, n);
        }

        if (projection == null && intent != null) {
            int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
            Intent data = intent.getParcelableExtra(EXTRA_RESULT_DATA);
            if (resultCode == Activity.RESULT_OK && data != null) startProjection(resultCode, data);
        }
        return START_NOT_STICKY;
    }

    private void startProjection(int resultCode, Intent data) {
        MediaProjectionManager manager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = manager.getMediaProjection(resultCode, data);
        if (projection == null) return;

        DisplayMetrics dm = getResources().getDisplayMetrics();
        int width = Math.max(1, dm.widthPixels);
        int height = Math.max(1, dm.heightPixels);
        int density = dm.densityDpi;

        thread = new HandlerThread("TVScannerCapture");
        thread.start();
        handler = new Handler(thread.getLooper());
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
        reader.setOnImageAvailableListener(r -> {
            android.media.Image image = null;
            try { image = r.acquireLatestImage(); } finally { if (image != null) image.close(); }
        }, handler);

        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { stopCapture(); }
        }, handler);

        virtualDisplay = projection.createVirtualDisplay(
                "TVSignalScanner", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(), null, handler);
    }

    private void stopCapture() {
        if (virtualDisplay != null) { virtualDisplay.release(); virtualDisplay = null; }
        if (reader != null) { reader.close(); reader = null; }
        if (projection != null) { projection.stop(); projection = null; }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel("scan", "Scanner", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    @Override public void onDestroy() {
        stopCapture();
        if (thread != null) { thread.quitSafely(); thread = null; }
        super.onDestroy();
    }

    @Override public android.os.IBinder onBind(Intent intent) { return null; }
}
