package com.ai.tradingviewscanner;

import android.app.*;import android.content.*;import android.media.projection.MediaProjectionManager;import android.net.Uri;import android.os.*;import android.provider.Settings;import android.widget.*;

public class MainActivity extends Activity {
 static final int REQ_CAPTURE=401; EditText symbols,timeframes; TextView buyStatus,sellStatus,log; CheckBox requireAll;
 @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
  symbols=findViewById(R.id.symbols);timeframes=findViewById(R.id.timeframes);buyStatus=findViewById(R.id.buyStatus);sellStatus=findViewById(R.id.sellStatus);log=findViewById(R.id.log);requireAll=findViewById(R.id.requireAll);
  findViewById(R.id.addBuy).setOnClickListener(v->pickImage(true)); findViewById(R.id.addSell).setOnClickListener(v->pickImage(false));
  findViewById(R.id.accessibility).setOnClickListener(v->{startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));});
  findViewById(R.id.start).setOnClickListener(v->requestCapture()); findViewById(R.id.stop).setOnClickListener(v->stopService(new Intent(this,ScreenScanService.class)));
 }
 void pickImage(boolean buy){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,buy?10:11);}
 @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(c!=RESULT_OK||d==null)return;if(r==10||r==11){if(d.getData()!=null){getPreferences(0).edit().putString(r==10?"buyTemplate":"sellTemplate",d.getData().toString()).apply();if(r==10)buyStatus.setText("نمونه BUY ذخیره شد");else sellStatus.setText("نمونه SELL ذخیره شد");}}else if(r==REQ_CAPTURE){Intent s=new Intent(this,ScreenScanService.class);s.putExtra(ScreenScanService.EXTRA_RESULT_CODE,c);s.putExtra(ScreenScanService.EXTRA_RESULT_DATA,d);if(Build.VERSION.SDK_INT>=26)startForegroundService(s);else startService(s);log.setText("وضعیت: اسکن صفحه فعال شد");}}
 void requestCapture(){MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);startActivityForResult(m.createScreenCaptureIntent(),REQ_CAPTURE);}
 @Override protected void onResume(){super.onResume();}
}
