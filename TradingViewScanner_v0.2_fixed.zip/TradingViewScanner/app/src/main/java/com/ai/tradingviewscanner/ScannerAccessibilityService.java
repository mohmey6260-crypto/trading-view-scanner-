package com.ai.tradingviewscanner;
import android.accessibilityservice.AccessibilityService;import android.view.accessibility.AccessibilityEvent;import android.view.accessibility.AccessibilityNodeInfo;import android.content.Intent;import android.os.Bundle;import java.util.*;
public class ScannerAccessibilityService extends AccessibilityService {
 static ScannerAccessibilityService instance; public void onServiceConnected(){instance=this;} public void onAccessibilityEvent(AccessibilityEvent e){} public void onInterrupt(){}
 public boolean findAndClickText(String text){AccessibilityNodeInfo r=getRootInActiveWindow();if(r==null)return false;return click(r,text);}
 boolean click(AccessibilityNodeInfo n,String t){if(t.equalsIgnoreCase(String.valueOf(n.getText()))){return n.performAction(AccessibilityNodeInfo.ACTION_CLICK);}for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo c=n.getChild(i);if(c!=null&&click(c,t))return true;}return false;}
}
